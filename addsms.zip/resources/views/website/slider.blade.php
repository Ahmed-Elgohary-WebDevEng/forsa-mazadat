<?php
include ('sl/carousel.php');
?>