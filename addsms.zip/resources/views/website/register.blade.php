<?php $page='reg'; ?>
@extends('website.layouts.layout')

@section('content')

@include ('website.webAuth.reg')
@stop
