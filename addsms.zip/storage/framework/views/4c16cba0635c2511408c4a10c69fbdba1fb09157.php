 <div class="text-center footer justify-content-center droid-arabic-kufi">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-5 mb-lg-0 droid-arabic-kufi">
                    <h4 class="text-uppercase mb-4 droid-arabic-kufi">اتصل بنا</h4>
                    <h1>0508250276⁩</h1>
					
                </div>
                <div class="col-md-4 mb-5 mb-lg-0 droid-arabic-kufi">
                    <h4 class="text-uppercase droid-arabic-kufi">روابط مواقع التواصل</h4>
                    <ul class="list-inline">
                        <li class="list-inline-item"><a class="btn btn-outline-light text-center btn-social rounded-circle" role="button" href="mailto:foras11@outlook.sa"><i class="fa-light fa-envelope"></i></a></li>
                        <li class="list-inline-item"><a class="btn btn-outline-light text-center btn-social rounded-circle" role="button" href="mailto:orasrealestat@gmail.com"><i class="fa fa-google-plus fa-fw"></i></a></li>
                        <li class="list-inline-item"><a class="btn btn-outline-light text-center btn-social rounded-circle" role="button" href="https://twitter.com/forasrealestat"><img src="<?php echo e(asset('img/x-twitter(1).svg')); ?>"> </a></li>
                      <!--  <li class="list-inline-item"><a class="btn btn-outline-light text-center btn-social rounded-circle" role="button" href="#"><i class="fa fa-dribbble fa-fw"></i></a></li> -->
                    </ul>
					 <h4 class="text-uppercase droid-arabic-kufi">عدد زوار الموقع</h4>
                        <div id="sfc7gq72mbhy7sc8bzhc1gxdlhp5upztt8l"></div>
                        <script type="text/javascript" src="https://counter3.optistats.ovh/private/counter.js?c=7gq72mbhy7sc8bzhc1gxdlhp5upztt8l&down=async" async></script>
                        <noscript><a href="https://www.freecounterstat.com" title="website counter"><img src="https://counter3.optistats.ovh/private/freecounterstat.php?c=7gq72mbhy7sc8bzhc1gxdlhp5upztt8l" border="0" title="website counter" alt="website counter"></a></noscript>
                </div>
                <div class="col-md-4">
                    <h4 class="text-uppercase mb-4 droid-arabic-kufi">من نحن</h4>
                    <p class="lead mb-0"><span>تحقيقاً لرؤية 2030 م 
أُنشئت منصة فُرص 
لنوفر لك كل المنصات الإلكترونية 
بين يديك تحت سقف واحد &nbsp;</span></p>
                </div>
            </div>
        </div>
    
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="js/freelancer.js"></script>
</div><?php /**PATH /var/www/vhosts/fors-sa.com/httpdocs/resources/views/website/includes/footer.blade.php ENDPATH**/ ?>