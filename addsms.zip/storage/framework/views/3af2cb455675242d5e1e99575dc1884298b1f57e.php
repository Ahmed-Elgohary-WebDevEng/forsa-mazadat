
<?php $__env->startSection('content'); ?>

<div class="content-body">
    <!-- row -->
    <div class="container-fluid">
        <div class="row page-titles">
            <ol class="breadcrumb d-flex justify-content-end" dir="ltr">

                <li class="breadcrumb-item active"> <a href="<?php echo e(url('auction')); ?>">المزادات</a></li>
                <li class="breadcrumb-item "> <a href="<?php echo e(route('home')); ?>">الرئيسية</a></li>
            </ol>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header  d-flex justify-content-between ">
                        <p class="text-center  fs-3 fw-bold"></p>
                        <p class="text-center  fs-3 fw-bold text-primary">عرض جميع المزادات</p>
                        <a href="<?php echo e(url('add-stakeholder')); ?>" class="btn btn-primary float-end">إضافة</a>
                    </div>
                    <div class="card-body" style="overflow-x:scroll; ">
                        <div class="container">
                            <div class="row">
                                
                            </div>
                            <table id="table11" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>أسم الشريك</th>
                                        <th>الشعار</th>
                                    </tr>
                                </thead>
                                <tbody id="myTable">
                                    <?php $__currentLoopData = $stakeholder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($item->id); ?></td>
                                        <td><?php echo e($item->name); ?></td>
                                        <td>
                                            <img src="<?php echo e(asset('uploads/logo/'.$item->logo)); ?>" width="70px" height="70px" alt="Image">
                                        </td>
                                        
                                        <td>
                                            <a href="<?php echo e(url('edit-stakeholder/'.$item->id)); ?>" class="btn btn-primary btn-sm ">تعديل</a>
                                        </td>
                                        <td>
                                            
                                            <form action="<?php echo e(url('delete-stakeholder/'.$item->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm ">حذف</button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/fors-sa.com/httpdocs/resources/views/dashboard/stakeholder/index.blade.php ENDPATH**/ ?>