

<?php $__env->startSection('content'); ?>

<div class="content-body" dir="rtl">
    <div class="container-fluid">
        <div class="row page-titles">
            <ol class="breadcrumb d-flex justify-content-end" dir="ltr">
                <li class="breadcrumb-item active"><a href="<?php echo e(url('edit_auctionitem/'.$Actionitems->id)); ?>">  تعديل  <?php echo e($Actionitems->name); ?></a></li>
                <li class="breadcrumb-item active"> <a href="<?php echo e(url('auctionitem/'.$Auction->id)); ?>"> محتوى مزاد <?php echo e($Auction->Title); ?></a></li>
                <li class="breadcrumb-item "> <a href="<?php echo e(url('auction')); ?>">المزادات</a></li>
                <li class="breadcrumb-item "> <a href="<?php echo e(route('home')); ?>">الرئيسية</a></li>
        </div>
    <!-- row -->
    <div class="row">
        <div class="col-xl-12">
           
    
                <?php if(session('status')): ?>
                    <h6 class="alert alert-success"><?php echo e(session('status')); ?></h6>
                <?php endif; ?>
    
                <div class="card">
                    <div class="card-header  d-flex justify-content-between ">
                        <p class="text-center  fs-3 fw-bold"></p>
                        <p class="text-center  fs-3 fw-bold text-primary">تعديل على المزاد </p>
                        <a href="<?php echo e(url('auction')); ?>" class="btn btn-danger float-end">رجوع</a>
                    </div>
                    <div class="card-body">

                        <div class="col-xl-12">
                            <form action="<?php echo e(url('update_auctionitem/'.$Actionitems->id.'/'.$Auction->id)); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                
                                <div class="row">
                                    <div class="mb-3 col-md-4">
                                        <label for="">اسم المزاد</label>
                                <input type="text" name="Acution_id" value="<?php echo e($Auction->Title); ?>" class="form-control" style="background-color: rgb(226, 224, 224)" disabled>

                                 
                                </div>
                                <div class="mb-3 col-md-4">
                                    <label for="">اسم القطعة </label>
                                    <input type="text" name="name" class="form-control" value="<?php echo e($Actionitems->name); ?>">
                            </div>
                            <div class="mb-3 col-md-4">
                                <label for=""> المساحة</label>
                                <input type="text" name="space" class="form-control" value="<?php echo e($Actionitems->space); ?>">
                                </div>
                                
                               
        
                          
                            <div class="form-group mb-3">
                                <button type="submit" class="btn btn-primary">حفظ التعديلات</button>
                            </div>
    
                        </form>
    
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/fors-sa.com/httpdocs/resources/views/dashboard/auctionItem/edit.blade.php ENDPATH**/ ?>