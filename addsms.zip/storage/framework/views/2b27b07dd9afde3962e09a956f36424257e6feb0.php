<?php $page='index'; ?>


<?php $__env->startSection('content'); ?>

<?php echo $__env->make('website.agents', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('website.auction', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('website.stakeholder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->startSection('script'); ?>
      <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>">

</script>


<script >
$(document).ready(function(){

   var url = document.location.toString();
    if (url.match('#')) {
        $('.nav-tabs a[href="#' + url.split('#')[1] + '"]')[0].click();
    } 

    //To make sure that the page always goes to the top
    setTimeout(function () {
        window.scrollTo(0, 0);
    },200);

  });
  </script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/fors-sa.com/httpdocs/resources/views/website/index.blade.php ENDPATH**/ ?>