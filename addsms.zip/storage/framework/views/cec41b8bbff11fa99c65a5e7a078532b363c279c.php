


<div class="w3-content w3-section " style="max-width:300px; margin-left:auto; margin-right:auto;">
<center><?php $__currentLoopData = $agent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<a href="<?php echo e($item->link); ?>" target="_blank" >
  <img class="mySlides text-cente" src="<?php echo e(asset('uploads/agentsLogo/'.$item->logo)); ?>" style="display:none;width:100%">
	</a> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></center>
</div>

<script>
var myIndex = 0;
carousel();

function carousel() {
  var i;
  var x = document.getElementsByClassName("mySlides");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";  
  }
  myIndex++;
  if (myIndex > x.length) {myIndex = 1}    
  x[myIndex-1].style.display = "block";  
  setTimeout(carousel, 4000); // Change image every 2 seconds
}
</script>

<?php /**PATH /var/www/vhosts/fors-sa.com/httpdocs/resources/views/website/agents.blade.php ENDPATH**/ ?>