
<?php $__env->startSection('content'); ?>
<div class="row justify-content-center h-100 align-items-center">
    <div class="col-md-7">
        <div class="form-input-content text-center error-page">
            <h1 class="error-text fw-bold">404</h1>
            <h4><i class="fa fa-exclamation-triangle text-warning"></i> The page you were looking for is not found!</h4>
            <p>You may have mistyped the address or the page may have moved.</p>
            <div>
                <a class="btn btn-primary" href="<?php echo e(route('home')); ?>">Back to Home</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/fors-sa.com/httpdocs/resources/views/errors/404.blade.php ENDPATH**/ ?>