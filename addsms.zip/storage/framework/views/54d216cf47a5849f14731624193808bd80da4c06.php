<?php
include ('sl/carousel.php');
?><?php /**PATH /var/www/vhosts/fors-sa.com/httpdocs/resources/views/website/slider.blade.php ENDPATH**/ ?>