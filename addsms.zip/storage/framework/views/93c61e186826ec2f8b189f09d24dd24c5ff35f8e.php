
<?php $__env->startSection('content'); ?>

<div class="content-body">
    <!-- row -->
    <div class="container-fluid"> 
        <div class="row page-titles">
            <ol class="breadcrumb d-flex justify-content-end" dir="ltr">
                <li class="breadcrumb-item active"> <a href="<?php echo e(url('auctionitem/'.$Auction->id)); ?>"> محتوى مزاد <?php echo e($Auction->Title); ?></a></li>
                <li class="breadcrumb-item "> <a href="<?php echo e(url('auction')); ?>">المزادات</a></li>
                <li class="breadcrumb-item "> <a href="<?php echo e(route('home')); ?>">الرئيسية</a></li>
            </ol>
        </div>
               <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header  d-flex justify-content-between ">
                        <p class="text-center  fs-3 fw-bold"> 
							<span class="text-primary"><?php echo e($counters); ?></span> :عدد المسجلين بالمزاد
						</p>
                        <p class="text-center  fs-3 fw-bold text-primary">عرض المسجلين بالمزاد</p>
                    </div>
                    <div class="card-body">
    
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th> اسم المزاد</th>
                                    <th>اسم الاول</th>
                                    <th> اسم الاخير </th>
                                    <th> الهوية</th>
                                    <th>الجوال</th>
                                    

                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $userlog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php if($item->Acution_id == $Auction->id): ?>
                                <tr>
                                    <td><?php echo e($item->id); ?></td>
                                     <td><?php echo e($Auction->Title); ?></td> 
                                    <td><?php echo e($item->Firstname); ?></td>
                                    <td><?php echo e($item->lastname); ?></td>
                                    <td><?php echo e($item->identity); ?></td>
                                    <td><?php echo e($item->phone); ?></td>
                                    
                                                                
                                   
                                       
                                </tr>
                               <?php endif; ?>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </tbody>
                        </table>
    
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/fors-sa.com/httpdocs/resources/views/dashboard/userlog/index.blade.php ENDPATH**/ ?>