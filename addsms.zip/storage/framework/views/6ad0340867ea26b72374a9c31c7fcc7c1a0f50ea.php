 
  <nav class="navbar bg-secondary navbar-light fixed-top  navbar-expand-xl fixed-top shadow-sm" dir="rtl" id="mainNav">
    <div class="container-fluid">
      <a class="navbar-brand" href="<?php echo e(url('/index')); ?>"><img src="<?php echo e(asset('img/logo.png')); ?>" width="100px"
          height="auto"></a>

      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">

    <!-- <span class="navbar-toggler-icon"></span> -->
		  <img src="<?php echo e(asset('img/iconss.png')); ?>">
      </button>

      <div class="collapse navbar-collapse droid-arabic-kufi  " id="navbarSupportedContent">

        <ul class="navbar-nav mx-right text-center d-flex justify-content-end ">

          <li class="nav-item">
            <a href="<?php echo e(url('/index')); ?>" class="nav-item nav-link mt-1 mx-2" >الرئيسية</a>
          </li>
			 <li class="nav-item">
            <a href="<?php echo e(url('/terms')); ?>" class="nav-item nav-link mt-1 mx-2" >شروط السياسات والخصوصية</a>
          </li>
  

 
      



          <li class="nav-item dropdown">

            <select  name="viewsitePlace"  id="viewsitePlace" class="viewsitePlace nav-item dropdown-toggle nav-link  " style="text-decoration: none; color:white" onchange="change('viewsitePlace')">
            
              <option  selected disabled>المناطق</option>
              <option  class="dropdown-item" style="text-decoration: none; color:rgb(7, 7, 7)" data-url="<?php echo e(url('/Auctions')); ?>" > الكل </option>
              <option  class="dropdown-item" style="text-decoration: none; color:rgb(7, 7, 7)" data-url="<?php echo e(url('regioncontent/'.$auctions->Region ='makka')); ?>"  >مكة المكرمة </option>
              <option  class="dropdown-item" style="text-decoration: none; color:rgb(0, 0, 0)" data-url="<?php echo e(url('regioncontent/'.$auctions->Region ='almadina')); ?>">المدينة المنورة </option>
              <option  class="dropdown-item" style="text-decoration: none; color:rgb(0, 0, 0)" data-url="<?php echo e(url('regioncontent/'.$auctions->Region ='riyadh')); ?>">الرياض </option>
              <option  class="dropdown-item" style="text-decoration: none; color:rgb(0, 0, 0)" data-url="<?php echo e(url('regioncontent/'.$auctions->Region ='qassim')); ?>">القصيم </option>
              <option  class="dropdown-item" style="text-decoration: none; color:rgb(0, 0, 0)" data-url="<?php echo e(url('regioncontent/'.$auctions->Region ='haael')); ?>">حائل </option>
              <option  class="dropdown-item" style="text-decoration: none; color:rgb(0, 0, 0)" data-url="<?php echo e(url('regioncontent/'.$auctions->Region ='alsharqia')); ?>" >المنطقة الشرقية</option>
              <option  class="dropdown-item" style="text-decoration: none; color:rgb(0, 0, 0)" data-url="<?php echo e(url('regioncontent/'.$auctions->Region ='aljuof')); ?>">الجوف </option>
              <option  class="dropdown-item" style="text-decoration: none; color:rgb(0, 0, 0)" data-url="<?php echo e(url('regioncontent/'.$auctions->Region ='tabuk')); ?>" >تبوك </option>
              <option  class="dropdown-item" style="text-decoration: none; color:rgb(0, 0, 0)" data-url="<?php echo e(url('regioncontent/'.$auctions->Region ='najran')); ?>">نجران </option>
              <option  class="dropdown-item" style="text-decoration: none; color:rgb(0, 0, 0)" data-url="<?php echo e(url('regioncontent/'.$auctions->Region ='jazan')); ?>">جازان </option>
              <option  class="dropdown-item" style="text-decoration: none; color:rgb(0, 0, 0)" data-url="<?php echo e(url('regioncontent/'.$auctions->Region ='albaha')); ?>">الباحة </option>
              <option  class="dropdown-item" style="text-decoration: none; color:rgb(0, 0, 0)" data-url="<?php echo e(url('regioncontent/'.$auctions->Region ='shmaleah')); ?>" >المنطقة الشمالية </option>
              <option  class="dropdown-item" style="text-decoration: none; color:rgb(0, 0, 0)" data-url="<?php echo e(url('regioncontent/'.$auctions->Region ='asser')); ?>" >عسير </option>

            </select>
          </li>



      


  

          <li class="nav-item dropdown">

            <select  name="viewsitePlace"  id="viewsitePlace" class="viewsiteType nav-item dropdown-toggle nav-link  " style="text-decoration: none; color:white" onchange="change('viewsiteType')">

              <option  selected disabled>نوع المزاد</option>

          <option  class="dropdown-item" style="text-decoration: none; color:rgb(7, 7, 7)" value="<?php echo e(url('typecontent/'.$auctions->type ='onsite')); ?>">حضوري</option>
          <option  class="dropdown-item" style="text-decoration: none; color:rgb(0, 0, 0)" value="<?php echo e(url('typecontent/'.$auctions->type ='online')); ?>">إلكتروني </option>
          <option  class="dropdown-item" style="text-decoration: none; color:rgb(0, 0, 0)" value="<?php echo e(url('typecontent/'.$auctions->type ='mixed')); ?>">هجين </option>

        </select>
      </li>

        </ul>
       
            
         

       

      </div>

    </div>
  </nav>
<?php /**PATH /var/www/vhosts/fors-sa.com/httpdocs/resources/views/website/includes/nav.blade.php ENDPATH**/ ?>