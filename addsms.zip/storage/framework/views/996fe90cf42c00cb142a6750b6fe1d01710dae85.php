<div class="container-lg mx-auto mt-5 droid-arabic-kufi overflow-x-hidden">

  <ul class="nav nav-pills p-0 nav-justified mb-3" id="pills-tab" role="tablist">


    <li class="nav-item" role="presentation">
      <button class="nav-link active " id="pills-home-tab" style="background-color:#FFC000" data-bs-toggle="pill"
        data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home"
        aria-selected="true">قادم</button>
    </li>


    <li class="nav-item" role="presentation">
      <button class="nav-link " id="pills-profile-tab" style="background-color:#FFC000" data-bs-toggle="pill"
        data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile"
        aria-selected="false">جاري</button>
    </li>


    <li class="nav-item" role="presentation">
      <button class="nav-link  " id="pills-contact-tab" style="background-color:#FFC000 ;  " data-bs-toggle="pill"
        data-bs-target="#pills-contact" type="button" role="tab" aria-controls="pills-contact"
        aria-selected="false">منتهي</button>
    </li>

  </ul>
 
  <div class="tab-content" id="pills-tabContent">


    
 
  <!-- 1 -->
  <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab" tabindex="0">
    <div class="row row-cols-1 row-cols-md-3 g-4" dir="rtl">
      <?php $__currentLoopData = $auctions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if( $item->dateOfStarting > Carbon\Carbon::today()->toDateString()): ?>
      <div class="col-sm-3 col-md-4  ">
        <div class="card content " >
          <img src="<?php echo e(asset('uploads/auction/'.$item->image)); ?>" alt="" width="30" height="150"
            class="card-img-top mt-3">
			<a class="btn Btn-position rounded-pill btn-outline-Green Btn-lightGreen "> قادم </a>

          <a class="btn Btn-position rounded-pill btn-outline-Red Btn-lightRed mt-5 ">
            <?php if($item->type == "onsite"): ?>
            <?php echo e("حضوري"); ?>

            <?php elseif($item->type == "online"): ?>
            <?php echo e("إلكتروني"); ?>

            <?php elseif($item->type == "mixed"): ?>
            <?php echo e("هجين"); ?>

            <?php endif; ?>
          </a>
          <div class="card-body">
            <h5 class="card-title text-center mt-4" style="color: rgb(35, 96, 86);"><?php echo e($item->Title); ?></h5>

            <div class="row">
              <div class="col-6">
                <p class="card-text " style="color: rgb(83, 210, 187);font-size:12px"> عدد المنتجات: <span
                    style="color: rgb(35, 96, 86);">
                    <?php echo e($item->description); ?> </span></p>
              </div>
              <div class="col-6">
                <p class="card-text" style="color: rgb(83, 210, 187);font-size:11px"> المنطقة: <span
                    style="color: rgb(35, 96, 86);">
                    <?php if($item->Region =='riyadh' ): ?>
                    <?php echo e("الرياض"); ?>

                    <?php elseif($item->Region =='makka'): ?>
                    <?php echo e("مكة المكرمة"); ?>

                    <?php elseif($item->Region =='almadina'): ?>
                    <?php echo e("المدينة المنورة"); ?>

                    <?php elseif($item->Region =='alsharqia'): ?>
                    <?php echo e("المنطقة الشرقية"); ?>

                    <?php elseif($item->Region =='aljuof'): ?>
                    <?php echo e("الجوف"); ?>

                    <?php elseif($item->Region =='tabuk'): ?>
                    <?php echo e("تبوك"); ?>

                    <?php elseif($item->Region =='haael'): ?>
                    <?php echo e("حائل"); ?>

                    <?php elseif($item->Region =='qassim'): ?>
                    <?php echo e("القصيم"); ?>

                    <?php elseif($item->Region =='najran'): ?>
                    <?php echo e("نجران"); ?>

                    <?php elseif($item->Region =='jazan'): ?>
                    <?php echo e("جازان"); ?>

                    <?php elseif($item->Region =='albaha'): ?>
                    <?php echo e("الباحة"); ?>

                    <?php elseif($item->Region =='shmaleah'): ?>
                    <?php echo e("المنطقة الشمالية"); ?>

                    <?php elseif($item->Region =='asser'): ?>
                    <?php echo e("عسير "); ?>

                    <?php endif; ?>
                  </span></p>
              </div>
            </div>

            <div class="row mt-2">
              <div class="col-6">
                <p class="card-text" style="color: rgb(83, 210, 187); font-size:14.5px"> البداية: <span
                    style="color: rgb(35, 96, 86);"> <?php echo e($item->dateOfStarting); ?></span></p>
              </div>
              <div class="col-6">
                <p class="card-text" style="color: rgb(83, 210, 187); font-size:14.5px"> النهاية: <span
                    style="color: rgb(35, 96, 86);"> <?php echo e($item->dateOfEnding); ?></span></p>
              </div>
            </div>

            <div class="row mt-2">
              <div class="col-8">
                <p class="card-text" style="color: rgb(83, 210, 187)"> <i class="fas fa-calendar-alt fs-5"> </i> يبدأ
                  بعد: <span style="color: rgb(35, 96, 86);">
                    <?php if( $item->dateOfStarting == Carbon\Carbon::today()->toDateString() &&
                    Carbon\Carbon::today()->toDateString() != $item->dateOfEnding ||$item->dateOfStarting <=
                      Carbon\Carbon::today()->toDateString() && Carbon\Carbon::today()->toDateString() < $item->
                        dateOfEnding ): ?>
                        <span class="wrap-countdown mercado-countdown" style="font-size: 15px; color:#3a3a38"
                          data-expire="<?php echo e(Carbon\Carbon::parse($item->dateOfEnding)->format('Y/m/d h:i:s')); ?>">
                        </span>
                        <?php else: ?>
                        <span class="wrap-countdown mercado-countdown fs-6" style="font-size: 15px; color:#3a3a38"
                          data-expire="<?php echo e(Carbon\Carbon::parse($item->dateOfStarting)->format('Y/m/d h:i:s')); ?>">
                        </span>
                        <?php endif; ?>
                  </span></p>
              </div>
              <div class="col-4">
                <a href="<?php echo e(url('AcutionItems/'.$item->slug)); ?>" class="btn btn-outline-warning float-start mt-4"
                  style="color: #fac68a;">المزيد </a>
              </div>
            </div>

          </div>
        </div>
      </div>
      <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>


  <!-- 2 -->
  <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab" tabindex="0">
    <div class="row row-cols-1 row-cols-md-3 g-4" dir="rtl">
      <?php $__currentLoopData = $auctions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if( $item->dateOfStarting == Carbon\Carbon::today()->toDateString() && Carbon\Carbon::today()->toDateString()
      != $item->dateOfEnding ||$item->dateOfStarting <= Carbon\Carbon::today()->toDateString() &&
        Carbon\Carbon::today()->toDateString() < $item->dateOfEnding ): ?>
         <!-- <div class="col-sm-3 col-md-3 me-sm-5 ms-sm-5 me-2 ms-2">-->
		          <div class="col-sm-3 col-md-4">

            <div class="card  content">
			<a class="btn Btn-position rounded-pill btn-outline-Green Btn-lightGreen "> جاري </a>

              <img src="<?php echo e(asset('uploads/auction/'.$item->image)); ?>" alt="" width="30" height="150"
                class="card-img-top mt-3">
              <a class="btn Btn-position rounded-pill btn-outline-Red Btn-lightRed mt-5 ">
                <?php if($item->type == "onsite"): ?>
                <?php echo e("حضوري"); ?>

                <?php elseif($item->type == "online"): ?>
                <?php echo e("إلكتروني"); ?>

                <?php elseif($item->type == "mixed"): ?>
                <?php echo e("هجين"); ?>

                <?php endif; ?>
              </a>
              <div class="card-body">
                <h5 class="card-title text-center mt-4 " style="color: rgb(35, 96, 86);"><?php echo e($item->Title); ?></h5>
                <div class="row">
                  <div class="col-6">
                    <p class="card-text" style="color: rgb(83, 210, 187);font-size:12px"> عدد المنتجات: <span
                        style="color: rgb(35, 96, 86);"><?php echo e($item->description); ?></span></p>
                  </div>
                  <div class="col-6">
                    <p class="card-text" style="color: rgb(83, 210, 187); font-size:11px"> المنطقة: <span
                        style="color: rgb(35, 96, 86); font-size:12px">
                        <?php if($item->Region =='riyadh' ): ?>
                        <?php echo e("الرياض"); ?>

                        <?php elseif($item->Region =='makka'): ?>
                        <?php echo e("مكة المكرمة"); ?>

                        <?php elseif($item->Region =='almadina'): ?>
                        <?php echo e("المدينة المنورة"); ?>

                        <?php elseif($item->Region =='alsharqia'): ?>
                        <?php echo e("المنطقة الشرقية"); ?>

                        <?php elseif($item->Region =='aljuof'): ?>
                        <?php echo e("الجوف"); ?>

                        <?php elseif($item->Region =='tabuk'): ?>
                        <?php echo e("تبوك"); ?>

                        <?php elseif($item->Region =='haael'): ?>
                        <?php echo e("حائل"); ?>

                        <?php elseif($item->Region =='qassim'): ?>
                        <?php echo e("القصيم"); ?>

                        <?php elseif($item->Region =='najran'): ?>
                        <?php echo e("نجران"); ?>

                        <?php elseif($item->Region =='jazan'): ?>
                        <?php echo e("جازان"); ?>

                        <?php elseif($item->Region =='albaha'): ?>
                        <?php echo e("الباحة"); ?>

                        <?php elseif($item->Region =='shmaleah'): ?>
                        <?php echo e("المنطقة الشمالية"); ?>

                        <?php elseif($item->Region =='asser'): ?>
                        <?php echo e("عسير"); ?>

                        <?php endif; ?>
                      </span></p>
                  </div>
                </div>
                  <div class="row mt-2">
                    <div class="col-6">
                      <p class="card-text" style="color: rgb(83, 210, 187)"> البداية:
                        <span style="color: rgb(35, 96, 86);"><?php echo e($item->dateOfStarting); ?></span>
                      </p>
                    </div>
                    <div class="col-6">
                      <p class="card-text" style="color: rgb(83, 210, 187)"> النهاية: <span
                          style="color: rgb(35, 96, 86);"><?php echo e($item->dateOfEnding); ?></span></p>
                    </div>
                  </div>
                  <div class="row mt-2">
                    <div class="col-8">
                      <p class="card-text " style="color: rgb(83, 210, 187)"> <i class="fas fa-calendar-alt fs-5 "> </i>
                        ينتهي بعد: <span style="color: rgb(35, 96, 86);">
                          <?php if( $item->dateOfStarting == Carbon\Carbon::today()->toDateString() &&
                          Carbon\Carbon::today()->toDateString() != $item->dateOfEnding ||$item->dateOfStarting <=
                            Carbon\Carbon::today()->toDateString() && Carbon\Carbon::today()->toDateString() < $item->
                              dateOfEnding ): ?>
                              <span class="wrap-countdown mercado-countdown" style="font-size: 15px; color:#3a3a38"
                                data-expire="<?php echo e(Carbon\Carbon::parse($item->dateOfEnding)->format('Y/m/d h:i:s')); ?>">
                              </span>
                              <?php else: ?>
                              <span class="wrap-countdown mercado-countdown fs-6" style="font-size: 15px; color:#3a3a38"
                                data-expire="<?php echo e(Carbon\Carbon::parse($item->dateOfStarting)->format('Y/m/d h:i:s')); ?>">
                              </span>
                              <?php endif; ?>
                        </span></p>
                    </div>
                    <div class="col-4">
                      <a href="<?php echo e(url('AcutionItems/'.$item->slug)); ?>" class="btn btn-outline-warning float-start mt-4"
                        style="color: #fac68a;">المزيد </a>
                    </div>
                  </div>

                </div>

              </div>
            </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
    </div>

    <!-- 3 -->
    <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab" tabindex="0">
      <div class="row row-cols-1 row-cols-md-3 g-4" dir="rtl">
        <?php $__currentLoopData = $auctions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if( $item->dateOfEnding == Carbon\Carbon::today()->toDateString() || $item->dateOfEnding <=
          Carbon\Carbon::today()->toDateString()): ?>
          <div class="col-sm-3 col-md-4">
            <div class="card content">
              <img src="<?php echo e(asset('uploads/auction/'.$item->image)); ?>" alt="" width="30" height="150"
                class="card-img-top mt-3 ">
              <a class="btn Btn-position rounded-pill btn-outline-Green Btn-lightGreen "> منتهي </a>
              <a class="btn Btn-position rounded-pill btn-outline-Red Btn-lightRed mt-5 ">
                <?php if($item->type == "onsite"): ?>
                <?php echo e("حضوري"); ?>

                <?php elseif($item->type == "online"): ?>
                <?php echo e("إلكتروني"); ?>

                <?php elseif($item->type == "mixed"): ?>
                <?php echo e("هجين"); ?>

                <?php endif; ?>
              </a>


              <div class="card-body">

                <h5 class="card-title text-center mt-4" style="color: rgb(35, 96, 86);"><?php echo e($item->Title); ?></h5>
                <div class="row">
                  <div class="col-6">
                    <p class="card-text" style="color: rgb(83, 210, 187); font-size:12px"> عدد المنتجات: <span
                        style="color: rgb(35, 96, 86);"><?php echo e($item->description); ?>

                      </span> </p>
                  </div>
                  <div class="col-6">
                    <p class="card-text" style="color: rgb(83, 210, 187);font-size:11px"> المنطقة: <span
                        style="color: rgb(35, 96, 86); font-size:12px">
                        <?php if($item->Region =='riyadh' ): ?>
                        <?php echo e("الرياض"); ?>

                        <?php elseif($item->Region =='makka'): ?>
                        <?php echo e("مكة المكرمة"); ?>

                        <?php elseif($item->Region =='almadina'): ?>
                        <?php echo e("المدينة المنورة"); ?>

                        <?php elseif($item->Region =='alsharqia'): ?>
                        <?php echo e("المنطقة الشرقية"); ?>

                        <?php elseif($item->Region =='aljuof'): ?>
                        <?php echo e("الجوف"); ?>

                        <?php elseif($item->Region =='tabuk'): ?>
                        <?php echo e("تبوك"); ?>

                        <?php elseif($item->Region =='haael'): ?>
                        <?php echo e("حائل"); ?>

                        <?php elseif($item->Region =='qassim'): ?>
                        <?php echo e("القصيم"); ?>

                        <?php elseif($item->Region =='najran'): ?>
                        <?php echo e("نجران"); ?>

                        <?php elseif($item->Region =='jazan'): ?>
                        <?php echo e("جازان"); ?>

                        <?php elseif($item->Region =='albaha'): ?>
                        <?php echo e("الباحة"); ?>

                        <?php elseif($item->Region =='shmaleah'): ?>
                        <?php echo e("المنطقة الشمالية"); ?>

                        <?php elseif($item->Region =='asser'): ?>
                        <?php echo e("عسير"); ?>

                        <?php endif; ?>
                      </span></p>
                  </div>
                </div>
                <div class="row mt-2">
                  <div class="col-6">
                    <p class="card-text" style="color: rgb(83, 210, 187)"> البداية: <span
                        style="color: rgb(35, 96, 86);"><?php echo e($item->dateOfStarting); ?></span></p>
                  </div>
                  <div class="col-6">
                    <p class="card-text" style="color: rgb(83, 210, 187)"> النهاية: <span
                        style="color: rgb(35, 96, 86);"><?php echo e($item->dateOfEnding); ?></span></p>
                  </div>
                </div>
                <div class="row mt-2">
                  <div class="col-8">

                    <p class="card-text" style="color: rgb(83, 210, 187)"> <i class="fas fa-calendar-alt fs-5"> </i>
                      منتهى <span style="color: rgb(35, 96, 86);">
                        <?php if( $item->dateOfStarting == Carbon\Carbon::today()->toDateString() &&
                        Carbon\Carbon::today()->toDateString() != $item->dateOfEnding ||$item->dateOfStarting <=
                          Carbon\Carbon::today()->toDateString() && Carbon\Carbon::today()->toDateString() < $item->
                            dateOfEnding ): ?>
                            <span class="wrap-countdown mercado-countdown" style="font-size: 15px; color:#3a3a38"
                              data-expire="<?php echo e(Carbon\Carbon::parse($item->dateOfEnding)->format('Y/m/d h:i:s')); ?>">
                            </span>
                            <?php else: ?>
                            <span class="wrap-countdown mercado-countdown fs-6" style="font-size: 15px; color:#3a3a38"
                              data-expire="<?php echo e(Carbon\Carbon::parse($item->dateOfStarting)->format('Y/m/d h:i:s')); ?>">
                            </span>
                            <?php endif; ?>
                      </span></p>
                  </div>
                  <div class="col-4">
                    <a href="<?php echo e(url('AcutionItems/'.$item->slug)); ?>" class="btn btn-outline-warning float-start mt-4"
                      style="color: #fac68a;">المزيد </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>


		</div>	  
  </div>

<?php /**PATH /var/www/vhosts/fors-sa.com/httpdocs/resources/views/website/auction.blade.php ENDPATH**/ ?>