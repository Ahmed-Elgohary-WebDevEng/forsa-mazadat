<?php $page='auctionditailes'; ?>


<?php $__env->startSection('content'); ?>

<!-- Button trigger modal -->


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel"><?php echo e($auction->Title); ?></h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <?php echo e($auction->description); ?>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إغلاق</button>
      </div>
    </div>
  </div>
</div>

<div class="container body-content " dir="rtl">
  <h1 class="text-center droid-arabic-kufi fs-5" style="color: rgb(35, 96, 86);"><?php echo e($auction->Title); ?></h1>
  <div class="row pt-3 droid-arabic-kufi">
	  
    <div class=" imgcol">
      <div class="card-group ">
        <div class="card" style="background-color: rgb(255, 255, 255);">
          <div class="card-body">
            <div class="card">
              <div class="card-body " style="background-color: #c4c3bf">
                <span>              
                  <ul class="nav mainnave d-flex justify-content-evenly">
                  
               
					  
					   <li class="nav-item  navitem mt-1 ms1">
                      <a class="nav-link " href="#" style="color:#3a3a38">
						  
						  
						  <h5 style="color:rgb(35, 96, 86);"></h5> </a>

                        <?php if( $auction->dateOfStarting == Carbon\Carbon::today()->toDateString() &&
                                    Carbon\Carbon::today()->toDateString() != $auction->dateOfEnding ||$auction->dateOfStarting <=
                                      Carbon\Carbon::today()->toDateString() && Carbon\Carbon::today()->toDateString() < $auction->dateOfEnding ): ?>                                              
                        <div class="wrap-countdown mercado-countdown fs-6" data-expire="<?php echo e(Carbon\Carbon::parse($auction->dateOfEnding)->format('Y/m/d h:i:s')); ?>"></div>
                        <?php else: ?>
                        <div class="wrap-countdown mercado-countdown fs-6" style="font-size: 12px; color:#3a3a38" data-expire="<?php echo e(Carbon\Carbon::parse($auction->dateOfStarting)->format('Y/m/d h:i:s')); ?>"></div>
                        <?php endif; ?>
                    </li>
					
						   <li class="nav-item borderGreen navsm mt-2 ms-1  ">
                                                    <img class=" mt-1 me-2" src="<?php echo e(asset('uploads/auction/'.$auction->PlatformImage)); ?>" alt="" style="width:75%; height:55px">
                    </li>
						   
                    <?php if($auction->ShowInfath == 'yes' ): ?>
                    <li class="nav-item navsm1 borderGreen mt-2 " style="width:70px">
                     <a class=" me-1" href="https://infath.gov.sa/web/guest/auctions"> <img class="col-md-4 mt-1 mes nfathimg" src="<?php echo e(asset('img/mazadat.jpg')); ?>" style=" height:55px" ></a>
						
                    </li>
                   <?php endif; ?>  
						     <li class="nav-item elect borderGreen mt-2 ms-1" style="width:80px">
                    <div class="me-2" style="font-size:14px">
					  
<?php if($auction->type == "onsite"): ?>
						  
                    <a class="nav-link "  href="#" style="color:#3a3a38"><i class="fas fa-gavel fs-3 " style="color:#3a3a38" ></i></a>

<?php echo e("حضوري"); ?>

<?php elseif($auction->type == "online"): ?>
						 <a class="nav-link "  href="#" style="color:#3a3a38"><i class="fas fa-photo-video  fs-3 " style="color:#3a3a38" ></i></a>
<?php echo e("إلكتروني"); ?>

<?php elseif($auction->type == "mixed"): ?>
						 <a class="nav-link "  href="#" style="color:#3a3a38"><i class="fas fa-photo-video fs-3 " style="color:#3a3a38" ></i></a>
<?php echo e("هجين"); ?>

<?php endif; ?>
                </div>
                  </li>
                       <li class="nav-item borderGreen mt-2 ms-1" style="width:85px">
                      <div class="me-3" style="font-size:14px">
                      <a class="nav-link "  href="#" style="color:#3a3a38"><i class="fas fa-calendar-alt fs-3" style="color:#3a3a38" ></i></a>  <?php echo e($auction->dateOfStarting); ?></div> 
                    </li>
						   <li class="nav-item borderGreen mt-2 ms-1" style="width:85px">
                      <div class="me-3" style="font-size:14px">
                      <a class="nav-link "  href="#" style="color:#3a3a38"><i class="fas fa-calendar-alt fs-3" style="color:#3a3a38" ></i></a>  <?php echo e($auction->dateOfEnding); ?></div> 
                    </li>
					   <?php if($auction->type == "onsite"|| $auction->type == "mixed"): ?>
   <li class="nav-item borderGreen mt-2 ">
                    <div class="" style="font-size:14px">
                      <a class="nav-link "  href="<?php echo e($auction->onsiteLinkoo); ?>" style="color:#3a3a38">
						  <i class="fas fa-map-marker-alt fs-3 me-2" style="color:#3a3a38; text-align: center;" ></i></a><?php echo e($auction->PlatformName); ?></div> 
                    </li>
    <li class="nav-item borderGreen mt-2 ">
                      <div class="" style="font-size:14px">
                      <a class="nav-link "  href="<?php echo e($auction->onsiteLink); ?>" style="color:#3a3a38">
						 <i class="fas fa-tv  fs-3 me-3" style="color:#3a3a38" ></i></a>  رابط بث المزاد</div> 
                    </li>
						 
						
				 
					  					  <?php endif; ?>

						  </ul>
				  <ul class="nav d-flex justify-content-center mt-3">

                   <div class="row">
					   <div class="col-6">
					  <li class="nav-item  ">
                  <a href="<?php echo e(url('userLog/'.$auction->id)); ?>" class="img" style="text-decoration: none"><img class="entermzadimage " src="<?php echo e(asset('img/clickk.png')); ?>" width="50%"></a>
					  </li>
					   </div>
			 <div class="col-6">

					  <li class="nav-item   ">
<a href="<?php echo e(url('reminder/'.$auction->id)); ?>" class="img" style="text-decoration: none">
                <img class="subscribeImage" src="<?php echo e(asset('img/rem.png')); ?>"width="80%">
                </a>
					  </li>
					   </div>
					  </div>
                  </ul>  
                
              </div>
            </div>
            
          <div class="row mt-5">

           <div class="col-md-5 " dir="lrt" >

             
              </div>


              <div class="col-md-7">
              

    </div>
              </div>

          </div>
        </div>
      </div>
    </div>


    <div class="  itemcol "  >
      <div class="card overflow-y-auto " style="height:425px">
        <div class="card-body">
          <h5 class="card-title droid-arabic-kufi">بنود المزاد</h5>

          <div class="card  w-auto ">
            <?php $__currentLoopData = $auction->acution_item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $auctionitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <ul class="list-group list-group-flush">
              <li class="list-group-item"><?php echo e($auctionitem->name); ?> - <span>
                  مساحة: <?php echo e($auctionitem->space); ?></span></li>

            </ul>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </div>

        </div>
      </div>
    </div>
  </div>

 
<?php $__env->startSection('script'); ?>


<?php $__env->stopSection(); ?>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/fors-sa.com/httpdocs/resources/views/website/Actiondetailes.blade.php ENDPATH**/ ?>