<?php $page='auctionditailes'; ?>


<?php $__env->startSection('content'); ?>

<div class="content-body droid-arabic-kufi" dir="rtl">
    <div class="container-fluid">

    <div class="row">
        <div class="col-xl-12">

            <?php if(session('status')): ?>
                <h6 class="alert alert-success"><?php echo e(session('status')); ?></h6>
            <?php endif; ?>

            <div class="card">                
                  
                <div class="card-body">
                    <form action="<?php echo e(url('userLog/'.$Auction->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="row">
                            <div class="mb-3 col-md-6">
                                <label for="">اسم المزاد</label>
                                <input type="text" name="Acution_id" value="<?php echo e($Auction->Title); ?>" class="form-control" style="background-color: rgb(226, 224, 224)" disabled>

                            
                        </div>
                       
                        </div>
                        
                        <div class="row">
                            <div class="mb-3 col-md-6">
                                <label for="">اسم الاول </label>
                                <input type="text" name="Firstname" class="form-control">
                        </div>
                            <div class="mb-3 col-md-6">
                                <label for="">الاسم الاخير</label>
                                <input type="text" name="lastname" class="form-control">
                            </div>
                        
                          
                        </div>
                        
                        <div class="row">
                            <div class="mb-3 col-md-6">
                                <label for="">الهوية</label>
                                <input type="text" name="identity" class="form-control">
                            </div>
                            <div class="mb-3 col-md-6">
                                <label for=""> الجوال</label>
                                <input type="text" name="phone" class="form-control">
                            </div>
                        
                            
                        </div>

                         
                        <div class="form-group mb-3">
                            <button type="submit" class="btn btn-primary">الدخول </button>
                        </div>

                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/fors-sa.com/httpdocs/resources/views/website/UserLog.blade.php ENDPATH**/ ?>