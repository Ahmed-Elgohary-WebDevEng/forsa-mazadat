<?php $page='auctionditailes'; ?>


<?php $__env->startSection('content'); ?>

<div class="content-body" dir="rtl">
    <div class="container-fluid">

    <div class="row">
        <div class="col-xl-12">

            <?php if(session('status')): ?>
                <h6 class="alert alert-success"><?php echo e(session('status')); ?></h6>
            <?php endif; ?>

            <div class="card">                
                  
                <div class="card-body">
                    <div class="text-center">  مرحبا بك سيتم تحويلك تلقائيا في حال لم يعمل التحويل التلقائي انقر على الرابط <?php echo e($userlog->Firstname); ?></div>
                    <div class="text-center">  رابط المزاد <a href=" <?php echo e($Auction->link); ?>"> الرابط انقر هنا  </a></div>
					    <meta http-equiv = "refresh" content = "2; url = <?php echo e($Auction->link); ?>" />


                </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/fors-sa.com/httpdocs/resources/views/website/link.blade.php ENDPATH**/ ?>