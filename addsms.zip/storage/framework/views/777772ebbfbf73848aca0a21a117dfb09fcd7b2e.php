<h2 class="title-join text-center mt-5 fs-3 mb-5 " style="color:rgb(35, 96, 86);"> شركاء النجاح


  <div class="logo">
    <div class="logo_slider">
  <ul>
    <?php $__currentLoopData = $stakeholder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <li><a><img src="<?php echo e(asset('uploads/logo/'.$item->logo)); ?>" alt=""></a></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
  </ul>
  </div>
  </div>
	<?php /**PATH /var/www/vhosts/fors-sa.com/httpdocs/resources/views/website/stakeholder.blade.php ENDPATH**/ ?>