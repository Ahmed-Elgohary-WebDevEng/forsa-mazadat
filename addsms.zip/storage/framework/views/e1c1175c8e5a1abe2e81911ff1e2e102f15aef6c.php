
<?php $__env->startSection('content'); ?>



<div class="content-body" dir="rtl">
    <div class="container-fluid">
        <div class="row page-titles">
            <ol class="breadcrumb d-flex justify-content-end" dir="ltr">
                <li class="breadcrumb-item active"><a href="<?php echo e(url('add-agents')); ?>">إضافة وكيل</a></li>
                <li class="breadcrumb-item "> <a href="<?php echo e(url('/agents')); ?>">عرض  الوكلاء</a></li>
                <li class="breadcrumb-item "> <a href="<?php echo e(route('home')); ?>">الرئيسية</a></li>
            </ol>
        </div>
    <!-- row -->
    <div class="row">
        <div class="col-xl-12">

            <?php if(session('status')): ?>
                <h6 class="alert alert-success"><?php echo e(session('status')); ?></h6>
            <?php endif; ?>

            <div class="card">                
                    <div class="card-header  d-flex justify-content-between ">
                        <p class="text-center  fs-3 fw-bold"></p>
                        <p class="text-center  fs-3 fw-bold text-primary">إضافة وكيل</p>
                        <a href="<?php echo e(url('/agents')); ?>" class="btn btn-danger float-end">رجوع</a>
                    </div>
                <div class="card-body">
                    <form action="<?php echo e(url('add-agents')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="row">

                            <div class="mb-3 col-md-4">
                                <label for=""> اسم الشريك</label>
                                <input type="text" name="name" class="form-control">
                            </div>
                            <div class="mb-3 col-md-4">
                                <label for="">الرابط</label>
                                <input type="text" name="link" class="form-control">
                            </div>
                            <div class="mb-3 col-md-4">
                                <label for="">الشعار</label>
                                <input type="file" name="logo" class="form-control">
                            </div>
                            
                        <div class="form-group mb-3">
                            <button type="submit" class="btn btn-primary">اضف </button>
                        </div>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>









<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/fors-sa.com/httpdocs/resources/views/dashboard/agents/create.blade.php ENDPATH**/ ?>