<?php $page='index'; ?>


<?php $__env->startSection('content'); ?>


<?php echo $__env->make('website.auction', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('script'); ?>
      <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>">

</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/fors-sa.com/httpdocs/resources/views/website/allRegion.blade.php ENDPATH**/ ?>