
<?php $__env->startSection('content'); ?>

<div class="content-body">
    <!-- row -->
    <div class="container-fluid"> 
        <div class="row page-titles">
            <ol class="breadcrumb d-flex justify-content-end" dir="ltr">
                <li class="breadcrumb-item active"> <a href="<?php echo e(url('auctionitem/'.$Auction->id)); ?>"> محتوى مزاد <?php echo e($Auction->Title); ?></a></li>
                <li class="breadcrumb-item "> <a href="<?php echo e(url('auction')); ?>">المزادات</a></li>
                <li class="breadcrumb-item "> <a href="<?php echo e(route('home')); ?>">الرئيسية</a></li>
            </ol>
        </div>
               <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header  d-flex justify-content-between ">
                        <p class="text-center  fs-3 fw-bold"></p>
                        <p class="text-center  fs-3 fw-bold text-primary">عرض  محتوى المزاد</p>
                        <a href="<?php echo e(url('add_auctionitem/'.$Auction->id)); ?>" class="btn btn-primary float-end">أضف جديد</a>
                    </div>
                    <div class="card-body">
    
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>اسم المزاد</th>
                                    <th> اسم القطعة </th>
                                    <th>المساحة</th>

                                   
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $Actionitems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php if($item->Acution_id == $Auction->id): ?>
                                <tr>
                                    <td><?php echo e($item->id); ?></td>
                                    <td><?php echo e($item->Acution->Title); ?></td>
                                    <td><?php echo e($item->name); ?></td>
                                    <td><?php echo e($item->space); ?></td>

                                   
                                                                
                                    <td>
                                        <a href="<?php echo e(url('edit_auctionitem/'.$item->id.'/'.$Auction->id)); ?>" class="btn btn-primary btn-sm">تعديل</a>
                                    </td>
                                    <td>
                                        
                                        <form action="<?php echo e(url('delete_auctionitem/'.$item->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm">حذف</button>
                                        </form>
                                    </td>
                                </tr>
                               <?php endif; ?>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </tbody>
                        </table>
    
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/fors-sa.com/httpdocs/resources/views/dashboard/auctionItem/index.blade.php ENDPATH**/ ?>