
<?php $__env->startSection('content'); ?>

<div class="content-body">
    <!-- row -->
    <div class="container-fluid">
        <div class="row page-titles">
            <ol class="breadcrumb d-flex justify-content-end" dir="ltr">

                <li class="breadcrumb-item active"> <a href="<?php echo e(url('auction')); ?>">المزادات</a></li>
                <li class="breadcrumb-item "> <a href="<?php echo e(route('home')); ?>">الرئيسية</a></li>
            </ol>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header  d-flex justify-content-between ">
                        <p class="text-center  fs-3 fw-bold"></p>
                        <p class="text-center  fs-3 fw-bold text-primary">عرض جميع المزادات</p>
                        <a href="<?php echo e(url('add_auction')); ?>" class="btn btn-primary float-end">أضف جديد</a>
                    </div>
                    <div class="card-body" style="overflow-x:scroll; ">
                        <div class="container">
                            <div class="row">
                                 <div class="col-4">
                                    <select class="form-select" id='filterText' style='display:inline-block'
                                        onchange='filterText()'>
                                      
                                            <option style="text-decoration: none; color:#454343" selected disabled > المناطق </option>
                                            <option style="text-decoration: none; color:#454343"  value="all"> الكل </option>
                                            <option style="text-decoration: none; color:#454343"  value="مكة المكرمة">مكة المكرمة </option>
                                            <option style="text-decoration: none; color:#454343"  value="المدينة المنورة">المدينة المنورة </option>
                                            <option  style="text-decoration: none; color:#454343"  value="الرياض">الرياض </option>
                                            <option class="dropdown-item"
                                                style="text-decoration: none; color:#454343" value="القصيم">القصيم
                                                </a></option>
                                            <option class="dropdown-item"
                                                style="text-decoration: none; color:#454343" value="حائل">حائل
                                                </a></option>
                                            <option class="dropdown-item"
                                                style="text-decoration: none; color:#454343" value="المنطقة الشرقية">
                                                المنطقة الشرقية </a></option>
                                            <option class="dropdown-item"
                                                style="text-decoration: none; color:#454343" value="الجوف">الجوف
                                                </a></option>
                                            <option class="dropdown-item"
                                                style="text-decoration: none; color:#454343" value="تبوك">تبوك
                                            </option>
                                            <option class="dropdown-item"
                                                style="text-decoration: none; color:#454343" value="تبوك">تبوك
                                            </option>
                                            <option class="dropdown-item"
                                                style="text-decoration: none; color:#454343" value="جازان">جازان
                                            </option>
                                            <option class="dropdown-item"
                                                style="text-decoration: none; color:#454343" value="الباحة">الباحة
                                            </option>
                                            <option class="dropdown-item"
                                                style="text-decoration: none; color:#454343" value="المنطقة الشمالية">
                                                المنطقة الشمالية </option>
                                            <option class="dropdown-item"
                                                style="text-decoration: none; color:#454343" value="عسير">عسير
                                            </option>
                                
                                        </select>
                                </div>
                                <div class="col-4">
                                    <select class="form-select"  id="roleDropdown" onchange='filterText()'>
                                        <option style="text-decoration: none; color:#454343" disabled > نوع المزاد </option>

                                            <option  style="text-decoration: none; color:#454343" value="all">الكل</option>
                                            <option class="dropdown-item"
                                                style="text-decoration: none; color:#454343" value="حضوري">
                                                حضوري</a></option>
                                            <option class="dropdown-item"
                                                style="text-decoration: none; color:#454343" value="إلكتروني">
                                                إلكتروني </a></option>
                                            <option class="dropdown-item"
                                                style="text-decoration: none; color:#454343" value="هجين">هجين </a>
                                            </option>
                                        </select>
                                </div>
                             
                            </div>
                            <table id="table11" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>عنوان المزاد </th>
                                        <th>منطقة المزاد </th>
                                        <th>نوع المزاد </th>
                                        <th>تاريخ ووقت البداية المزاد </th>
                                        <th> إظهار انفاذ </th>
                                        <th> إسم المنصة </th>
                                        <th> محتوى</th>

                                    </tr>
                                </thead>
                                <tbody id="myTable">
                                    <?php $__currentLoopData = $auction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="content">
                                        <td><?php echo e($item->id); ?></td>
                                        <td><?php echo e($item->Title); ?></td>
                                        <td> <?php if($item->Region =='riyadh' ): ?>
                                            <?php echo e("الرياض"); ?>

                                            <?php elseif($item->Region =='makka'): ?>
                                            <?php echo e("مكة المكرمة"); ?>

                                            <?php elseif($item->Region =='almadina'): ?>
                                            <?php echo e("المدينة المنورة"); ?>

                                             <?php elseif($item->Region =='alsharqia'): ?>
                                            <?php echo e("المنطقة الشرقية"); ?>

                                                              <?php elseif($item->Region =='aljuof'): ?>
                                            <?php echo e("الجوف"); ?>

                                                              <?php elseif($item->Region =='tabuk'): ?>
                                            <?php echo e("تبوك"); ?>

                                                              <?php elseif($item->Region =='haael'): ?>
                                            <?php echo e("حائل"); ?>

                                                              <?php elseif($item->Region =='qassim'): ?>
                                            <?php echo e("القصيم"); ?>

                                                              <?php elseif($item->Region =='najran'): ?>
                                            <?php echo e("نجران"); ?>

                                                              <?php elseif($item->Region =='jazan'): ?>
                                            <?php echo e("جازان"); ?>

                                                              <?php elseif($item->Region =='albaha'): ?>
                                            <?php echo e("الباحة"); ?>

                                                              <?php elseif($item->Region =='shmaleah'): ?>
                                            <?php echo e("المنطقة الشمالية"); ?>

                                                              <?php elseif($item->Region =='asser'): ?>
                                            <?php echo e("عسير "); ?>

                                            <?php endif; ?></td>

                                        <td><?php if($item->type == "onsite"): ?>
                                            <?php echo e("حضوري"); ?>

                                            <?php elseif($item->type == "online"): ?>
                                            <?php echo e("إلكتروني"); ?>

                                            <?php elseif($item->type == "mixed"): ?>
                                            <?php echo e("هجين"); ?>

                                            <?php endif; ?></td>
                                        <td><?php echo e($item->dateOfStarting); ?> / <?php echo e($item->timeOfStarting); ?></td>
                                        <td><?php echo e($item->ShowInfath); ?></td>
                                        <td><?php echo e($item->PlatformName); ?></td>

                                        <td>
                                            <a href="<?php echo e(url('auctionitem/'.$item->id)); ?>"
                                                class="btn btn-primary btn-sm"> المحتوى</a>

                                        </td>
                                        <td>
                                            <a href="<?php echo e(url('edit_auction/'.$item->id)); ?>"
                                                class="btn btn-primary btn-sm">تعديل</a>

                                        </td>
                                        <td>
                                            <a href="<?php echo e(url('userlog/'.$item->id)); ?>" class="btn btn-primary btn-sm">سجل
                                                المشتركين</a>

                                        </td>
                                        <td>
                                            <a href="<?php echo e(url('reminderindex/'.$item->id)); ?>" class="btn btn-primary btn-sm">سجل
                                                المشتركين بالتذكير</a>

                                        </td>
                                        <td>
                                            
                                            <form action="<?php echo e(url('delete_auction/'.$item->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm">حذف</button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php $__env->startSection('script'); ?>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

        <script>
            function filterText()
	{  
		var rex = new RegExp($('#filterText').val());
		var rex2 = new RegExp($('#roleDropdown').val());
		if(rex =="/all/" || rex2 =="/all/"){clearFilter()}
         if(rex !="/all/") {
			$('.content').hide();
			$('.content').filter(function() {
			return rex.test($(this).text());
			}).show();
	} if(rex2 !="/all/"){
        $('.content').hide();
			$('.content').filter(function() {
			return rex2.test($(this).text());
			}).show();
    }  if (rex2 !="/all/" && rex !="/all/"){
        $('.content').hide();
			$('.content').filter(function() {
			 
            return rex2.test($(this).text()) && rex.test($(this).text());

			}).show();
            
			

		
	}
}
	
function filterText1()
	{  
		var rex2 = new RegExp($('#roleDropdown').val());
		if(rex2 =="/all/"){clearFilter()}else{
			$('.content').hide();
			$('.content').filter(function() {
			return rex2.test($(this).text());
			}).show();
	}
		
	}
	
function clearFilter()
	{
		$('.filterText').val('');
		$('.content').show();
	}
        </script>


        <?php $__env->stopSection(); ?>
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/fors-sa.com/httpdocs/resources/views/dashboard/auction/index.blade.php ENDPATH**/ ?>